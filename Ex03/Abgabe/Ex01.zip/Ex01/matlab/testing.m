A = create_bidiagonalmatrix(10);
B = golub_kahan_svd_step(A);